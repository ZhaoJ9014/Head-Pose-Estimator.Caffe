// Copyright (C) 2005  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_GUI_WIDGETs_
#define DLIB_GUI_WIDGETs_



#include "gui_widgets/widgets.h"



#endif // DLIB_GUI_WIDGETs_

